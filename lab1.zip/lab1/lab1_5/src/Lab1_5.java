public class Lab1_5 {
    public static void main(String[] args) {
        System.out.println("Integer.MAX_VALUE: " + Integer.MAX_VALUE);
        double d = Integer.MAX_VALUE + 3200.125;
        System.out.println("Double value: " + d);
        int maxInt = (int) d;
        System.out.println("Int after conversion: " + maxInt);
    }
}

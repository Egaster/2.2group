public class Lab1_4 {
    public static void main(String[] args) {
        double max = Double.MAX_VALUE;
        double min = 0.0;
        System.out.println(max);
        System.out.println(Math.nextUp(min));
    }
}
